/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo_w02s03_41425035.BagianA;
//Nama:john Reguel Pakpahan
//Nim:41425035
//Prodi:DIV TRPL
import java.util.Scanner;

public class GradeSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[] grades = new double[5]; // membuat array yg bisa menyimpan
        double total = 0;

        // Input nilai
        for(int i = 0; i < 5; i++) {
            System.out.print("Masukkan nilai ke-" + (i + 1) + ": ");
            grades[i] = scanner.nextDouble();
            total += grades[i];
        }

        // Hitung rata-rata
        double average = total / 5;
        System.out.println("Rata-rata nilai: " + average);

        // Kategorikan nilai
        char grade;
        if(average >= 85) grade = 'A';
        else if(average >= 70) grade = 'B';
        else if(average >= 60) grade = 'C';
        else if(average >= 50) grade = 'D';
        else grade = 'E';

        System.out.println("Grade: " + grade);

        // Tampilkan nilai tertinggi dan terendah
        double max = grades[0];
        double min = grades[0];

        for(int i = 1; i < 5; i++) {
            if(grades[i] > max) max = grades[i];
            if(grades[i] < min) min = grades[i];
        }

        System.out.println("Nilai tertinggi: " + max);
        System.out.println("Nilai terendah: " + min);
    }
        // 1. akan tetap jalan , tetapi  penilainya akan tidak akurat semisal serang guru 
    //memasukan nilai muridnya yg grade antara 100-1000 padahal sebenarnya 100 adalah nilai e , teteapi jika mengunakan itu aknamenjadi A
    
    // 2. maka haruslah kita membuat variabel jumlah dan  kita dapat mngisi itu dan dpt mengisi ini
    //nah variabel ini berfungsi untuk dpt mengubah jumlah isi array yg dpt terima oleh 
    // variabel grades
}
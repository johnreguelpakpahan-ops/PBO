/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MultilevelInheritance;

/**
 *
 * @author User
 */
public class Geeks {
    public static void main(String[] args){
        Car obj = new Car();
    }
}
